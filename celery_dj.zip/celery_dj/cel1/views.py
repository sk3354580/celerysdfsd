
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect

# Create your views here.

from celery import shared_task

from time import sleep
@shared_task
def sleepy(duration):
    sleep(10)
    return None

@shared_task
def index(request):
    sleepy.delay(10)
    # sleep(10)
    return redirect("add")

@shared_task
def add(x, y):
    x = 10
    y = 10
    return x + y


@shared_task
def mul(x, y):
    return x * y

