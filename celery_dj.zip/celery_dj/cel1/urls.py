from unicodedata import name
from django.urls import path
from . views import *
from .task import sleepy
urlpatterns = [
    path('',index,name='index'),
    path('sleepy',sleepy,name="sleepy"),
    path("add",add,name="add")
]
